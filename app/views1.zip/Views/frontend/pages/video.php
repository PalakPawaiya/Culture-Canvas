<?= $this->extend('frontend/layouts/front_layout1') ?>

<?= $this->section('frontend_content') ?>
<br><br>





<div class="container-lg">

    <div class="row">




        <h2 class="section-title text-center">View All Videos 🎥
        </h2>
        <br><br><br>






        <?php if (!empty($videothumbnails)): ?>
            <?php foreach ($videothumbnails as $row): ?>
                <div class="col-md-4 text-center mb-4">
                    <div class="category-img-container">
                        <a href="https://www.youtube.com/watch?v=EFZErAelIAI&t=2s" target="_blank">
                            <img src="<?= base_url('public/uploads/trainings/images/' . $row['image']); ?>"
                                class="image-hover-effect" alt="Sample Image"
                                alt="<?= esc($row['title']) ?> "
                                style="border: 2px solid black; border-radius: 3px;">

                        </a>
                    </div>
                    <p class="mt-2 fw-bold text-dark" style=" font-size: 20px; "><?= esc($row['title']) ?></p>
                    <div class="btn-group-custom w-100 " style="height: 50px; ">
                        <a href="<?= $row['ytvideolink']; ?>" class="btn btn-primary d-flex align-items-center justify-content-center"
                            target="_blank" style=" height: 40px; min-width:290px; white-space: nowrap; "> View Video</a></button>
                    </div>
                    <div class="d-flex gap-2">
                        <!-- Like Button -->
                        <button class="btn btn-primary flex-fill  share-btn"
                            style="height: 40px; min-width: 120px; white-space: nowrap; margin-top: 10px; margin-left: 10px; "
                            data-link="<?= $row['ytvideolink']; ?>">
                            <i class="fas fa-share-alt me-1"></i> &nbsp; Share
                        </button>



                        <?php
                        $LikeCount;
                        foreach ($likesById as $likecount) {
                            if (in_array($row['id'], $likecount)) {
                                $LikeCount =  $likecount['no_of_likes'];
                            }
                        }
                        ?>
                        <form action="<?= base_url('likes/toggleLike/video/' . $row['id']) ?>" method="post" style="display:inline;">
                            <?= csrf_field() ?>
                            <button type="submit" class="btn btn-outline-danger btn-primary d-flex align-items-center justify-content-center" style="height: 40px; min-width: 160px; padding: 0 16px; font-size: 16px; margin-top: 10px; ">
                                👍 Like (<?= $LikeCount + 10000 ?>)
                            </button>
                        </form>

                    </div>
                   

                </div>

            <?php endforeach; ?>
        <?php else: ?>
            <li>No Categories Found</li>
        <?php endif; ?>

 <!-- Pagination Links -->
<nav>
  <ul class="pagination">
    <?php for($i=1; $i<=$totalPages; $i++): ?>
      <li class="page-item <?= ($i==$currentPage)?'active':'' ?>">
        <a class="page-link" href="<?= base_url('videos?page='.$i.($search?'&q='.$search:'')) ?>"><?= $i ?></a>
      </li>
    <?php endfor; ?>
  </ul>
</nav>









        <!-- / Banner Blocks -->
    </div>

</div>
</section>











<?= $this->endSection() ?>