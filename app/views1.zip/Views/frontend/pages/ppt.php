<?= $this->extend('frontend/layouts/front_layout1') ?>

<?= $this->section('frontend_content') ?>
<br><br>


<section id="ppt" class="pb-5">
  <div class="container-lg">
    <div class="row">
      <div class="section-header d-flex flex-wrap justify-content-center my-4">
        <h2 class="section-title">View All PPT's 📊</h2>
      </div>
    </div>

    <div class="row">
      <?php if (!empty($ppts)): ?>
        <?php foreach ($ppts as $row): ?>
          <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm">
              <!-- Image -->
              <img src="<?= base_url('public/uploads/trainings/images/' . $row['image']); ?>"
                   alt="<?= esc($row['title']) ?>"
                   class="card-img-top"
                   style="height:200px; object-fit:cover;">

              <div class="card-body text-center">
                <!-- Title -->
                <h5 class="card-title"><?= esc($row['title']) ?></h5>

                <!-- Buttons -->
                <div class="d-flex justify-content-center gap-2 mb-3">
                  <a href="<?= $row['ytvideolink']; ?>" 
                     class="btn btn-primary btn-sm" 
                     target="_blank">View Video</a>

                  <button class="btn btn-primary btn-sm share-btn"
                          data-title="<?= esc($row['title']); ?>"
                          data-link="<?= base_url('public/uploads/ppts/' . $row['filename']); ?>">
                    <i class="fas fa-share-alt me-1"></i> Share
                  </button>
                </div>

                <?php
                $pptDownloadCount = 0;
                foreach ($downloadsById as $downloadcount) {
                    if ($row['id'] == $downloadcount['ppt_id']) {
                        $pptDownloadCount = $downloadcount['no_of_downloads'];
                    }
                }
                ?>

                <a href="<?= base_url('download/ppt/' . $row['id']) ?>" 
                   class="btn btn-primary btn-sm mb-2">
                  ⬇ Download PPT
                </a>

                <p class="mb-0">Total Downloads: <?= $pptDownloadCount ?></p>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <p>No Categories Found</p>
      <?php endif; ?>
    </div>
  </div>
</section>







<?= $this->endSection() ?>