<?php

namespace App\Controllers;

use App\Models\LikeModel;

class LikeController extends BaseController

{
     public function __construct()
  {
   
     $session = session(); 
        if (!$session->get('isLoggedIn')) {
          
            return redirect()->to('login');
        }
  }

    public function toggleLike($type, $id)
    {
        $likeModel = new LikeModel();
        $userId = session()->get('user_id'); 
        if (!$userId) {
            return redirect()->to('category/login')->with('error', 'Login required');
        }
        $likeModel->addLike($userId, $type, $id);
        $totalLikes = $likeModel->countLikes();
         [ 
        'totalLikes' => $totalLikes
    ];

    return redirect()->back()->with( 'success', 'File downloaded successfully' );
    
    }
}
